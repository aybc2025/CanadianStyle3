# הוראות מעבר למערכת המודולרית החדשה

## 📋 סקירה כללית

המערכת החדשה מחלקת את הקוד המונוליטי של `chapter.js` ל-6 קבצים מודולריים:

1. **chapter-manager.js** - מנהל מרכזי (מחליף את chapter.js)
2. **content-builders/core-builder.js** - תוכן בסיסי
3. **content-builders/box-builder.js** - תיבות מיוחדות
4. **content-builders/lists-builder.js** - רשימות ודוגמאות
5. **content-builders/chapter3-builder.js** - פרק 3 ספציפי
6. **content-builders/chapter4-builder.js** - פרק 4 ספציפי

---

## 🚀 שלבי ההטמעה

### שלב 1: יצירת מבנה התיקיות

```bash
cd CanadianStyle2main
mkdir -p js/content-builders
```

### שלב 2: העתקת הקבצים החדשים

העתק את הקבצים הבאים למיקומים המתאימים:

```
chapter-manager.js → js/chapter-manager.js

content-builders/core-builder.js → js/content-builders/core-builder.js
content-builders/box-builder.js → js/content-builders/box-builder.js
content-builders/lists-builder.js → js/content-builders/lists-builder.js
content-builders/chapter3-builder.js → js/content-builders/chapter3-builder.js
content-builders/chapter4-builder.js → js/content-builders/chapter4-builder.js
```

### שלב 3: גיבוי הקובץ הישן

**חשוב מאוד!** לפני מחיקה, צור גיבוי:

```bash
cp js/chapter.js js/chapter.js.backup
```

### שלב 4: עדכון chapter.html

פתח את `chapter.html` ועדכן את שורת ה-script:

**לפני:**
```html
<script src="js/chapter.js"></script>
```

**אחרי:**
```html
<script type="module" src="js/chapter-manager.js"></script>
```

**שים לב:** הוספנו `type="module"` כדי לאפשר import של builders!

### שלב 5: בדיקה מקומית

1. פתח את האתר בדפדפן מקומי
2. בדוק את פרק 1 - Abbreviations
3. בדוק את פרק 2 - Hyphenation
4. בדוק את פרק 3 - Spelling
5. בדוק את פרק 4 - Capitalization

**מה לבדוק:**
- ✅ הפרקים נטענים ללא שגיאות
- ✅ התוכן מוצג כראוי
- ✅ הניווט בין סעיפים עובד
- ✅ פס ההתקדמות עובד
- ✅ המעבר למבחן עובד

### שלב 6: בדיקת קונסולה

פתח את Developer Console (F12) ובדוק:
- ✅ אין שגיאות JavaScript
- ✅ אין שגיאות 404 (קבצים לא נמצאו)
- ✅ כל ה-builders נטענים בהצלחה

### שלב 7: Commit ו-Push

לאחר בדיקה מוצלחת:

```bash
git add js/chapter-manager.js
git add js/content-builders/
git commit -m "Refactor: Split chapter.js into modular builders"
git push origin main
```

### שלב 8: בדיקה ב-GitHub Pages

1. המתן מספר דקות לפרסום
2. כנס לאתר ב-GitHub Pages
3. בדוק שוב את כל הפרקים

### שלב 9: מחיקת הקובץ הישן (אופציונלי)

רק אחרי שאתה בטוח ש**הכל עובד**:

```bash
git rm js/chapter.js
git commit -m "Remove old chapter.js after migration"
git push origin main
```

---

## 🔍 פתרון בעיות נפוצות

### בעיה: "Failed to load module"

**סיבה:** הדפדפן לא מצא את ה-builders

**פתרון:**
1. בדוק ש-`type="module"` קיים ב-script tag
2. בדוק את נתיבי הקבצים ב-chapter-manager.js
3. בדוק שהקבצים באמת קיימים בתיקייה הנכונה

### בעיה: "CORS policy error"

**סיבה:** אי אפשר לטעון modules מ-file:// protocol

**פתרון:** השתמש ב-local server:
```bash
# Python
python -m http.server 8000

# Node.js
npx http-server
```

### בעיה: "contentBuilders is null"

**סיבה:** ה-builders לא נטענו בזמן

**פתרון:** בדוק שהפונקציה `loadBuilders()` הושלמה לפני `loadChapterData()`

### בעיה: התוכן לא מוצג

**סיבה:** builder לא מטפל במבנה נתונים מסוים

**פתרון:**
1. פתח את Developer Console
2. חפש שגיאות JavaScript
3. בדוק איזה builder אחראי על התוכן החסר
4. הוסף טיפול במבנה הנתונים הספציפי

---

## 📊 השוואה: לפני ואחרי

### לפני (chapter.js):
- ✗ 1 קובץ ענק (~2000 שורות)
- ✗ קשה לתחזוקה
- ✗ קשה לאתר באגים
- ✗ הוספת פרק חדש = עריכה של קובץ ענק

### אחרי (מערכת מודולרית):
- ✅ 6 קבצים קטנים וממוקדים
- ✅ קל לתחזוקה
- ✅ קל לאתר באגים
- ✅ הוספת פרק חדש = יצירת builder חדש

---

## 🎯 יתרונות המערכת החדשה

1. **מודולריות** - כל builder אחראי על סוג תוכן אחד
2. **שימוש חוזר** - builders משותפים בין פרקים
3. **תחזוקה קלה** - באג ברשימות? תקן רק ב-lists-builder.js
4. **הרחבה קלה** - פרק חדש? צור builder חדש
5. **קוד נקי** - כל קובץ קצר וקריא

---

## 📝 הוספת פרק חדש בעתיד

כשתרצה להוסיף פרק 5 (Numerical Expressions):

1. צור `chapter-05.json` עם התוכן
2. אם יש מבנים ייחודיים, צור `chapter5-builder.js`
3. ב-chapter-manager.js, הוסף את ה-builder החדש:

```javascript
if (chapterId === 5) {
    html += contentBuilders.chapter5.buildChapter5Content(content);
}
```

זהו! לא צריך לשנות שום דבר אחר.

---

## ✅ Checklist סופי

לפני שמסיימים את המעבר:

- [ ] כל הקבצים החדשים במקום הנכון
- [ ] chapter.html עודכן עם type="module"
- [ ] הגיבוי של chapter.js נוצר
- [ ] פרק 1 עובד
- [ ] פרק 2 עובד
- [ ] פרק 3 עובד
- [ ] פרק 4 עובד
- [ ] אין שגיאות בקונסולה
- [ ] ההתקדמות נשמרת
- [ ] המעבר למבחנים עובד
- [ ] האתר פועל ב-GitHub Pages

---

## 🆘 תמיכה

אם נתקעת, בדוק:
1. Developer Console (F12) לשגיאות
2. Network tab לקבצים שלא נטענו
3. קובץ הגיבוי chapter.js.backup

בהצלחה! 🎉
